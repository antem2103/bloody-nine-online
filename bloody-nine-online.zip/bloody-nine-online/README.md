# Bloody Nine Online

Four-player online trick-taking card game. Teams are seats 1+3 and 2+4.

## Run locally
- Node.js 18+
- `npm install`
- `npm start`
- Open `http://localhost:3000`

## Deploy
Deploy as a Node web service. Build command: `npm install`; start command: `npm start`.

This is an early playable prototype. It should be tested with four players before relying on it. Reconnection and persistent rooms are not implemented yet.
