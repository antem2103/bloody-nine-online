const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static('public'));
const rooms = new Map();
const suits = ['♠','♥','♦','♣'];
const ranks = ['7','8','9','10','J','Q','K','A'];
const value = r => ranks.indexOf(r);
const code = () => crypto.randomBytes(3).toString('hex').toUpperCase();
function freshDeck(){ return suits.flatMap(s=>ranks.map(r=>({suit:s,rank:r,id:s+r}))).sort(()=>Math.random()-.5); }
function publicState(room){ return {code:room.code, players:room.players.map((p,i)=>p?{seat:i,name:p.name,connected:p.connected}:null), phase:room.phase, turn:room.turn, trick:room.trick.map(x=>({seat:x.seat,card:x.card})), scores:room.scores, trickNo:room.trickNo, deckCount:room.deck.length, lead:room.lead, message:room.message}; }
function emitRoom(room){ room.players.forEach((p,i)=>{ if(p?.socketId) io.to(p.socketId).emit('state',{...publicState(room),hand:p.hand}); }); }
function deal(room){ room.deck=freshDeck(); room.players.forEach(p=>p.hand=[]); for(let n=0;n<4;n++) for(let i=0;i<4;i++) room.players[i].hand.push(room.deck.pop()); room.trick=[]; room.trickNo=1; room.turn=0; room.lead=0; room.phase='playing'; room.cardsTaken=[0,0]; room.points=[0,0]; room.message='Igra je počela!'; }
function finishTrick(room){ const winner=room.trick.reduce((best,x)=>value(x.card.rank)>value(best.card.rank)?x:best).seat; const winningTeam=winner%2; room.trick.forEach(x=>room.cardsTaken[x.seat%2]++); room.trick.forEach(x=>{ if(x.card.suit==='♥'&&x.card.rank==='9') room.points[x.seat%2]++; if(x.card.rank==='10') room.points[x.seat%2]++; }); room.trickNo++; room.trick=[]; room.lead=winner; room.turn=winner;
  if(room.deck.length){ for(let n=0;n<4;n++){ const i=(winner+n)%4; const card=room.deck.pop(); if(card) room.players[i].hand.push(card); } }
  if(room.players.every(p=>p.hand.length===0)){ const a=room.cardsTaken[0], b=room.cardsTaken[1]; if(a>b) room.points[0]+=2; else if(b>a) room.points[1]+=2; room.points[winningTeam]+=2; room.scores[0]+=room.points[0]; room.scores[1]+=room.points[1]; room.phase=room.scores.some(s=>s>=21)?'finished':'between'; room.message=room.phase==='finished'?(room.scores[0]>=21?'Tim igrača 1 i 3 pobjeđuje!':'Tim igrača 2 i 4 pobjeđuje!'):'Dijeljenje završeno. Spremni za novu rundu?'; }
  else room.message=`Štih je osvojio ${room.players[winner].name}.`;
}
io.on('connection', socket=>{
 socket.on('createRoom',({name})=>{ let c=code(); while(rooms.has(c)) c=code(); const room={code:c,players:[null,null,null,null],deck:[],trick:[],scores:[0,0],phase:'lobby',turn:0,trickNo:1,lead:0,message:'Čekamo četiri igrača.'}; rooms.set(c,room); join(socket,room,name); });
 socket.on('joinRoom',({code:c,name})=>{ const room=rooms.get(String(c||'').toUpperCase()); if(!room) return socket.emit('errorMsg','Soba ne postoji. Provjeri kod.'); join(socket,room,name); });
 function join(sock,room,name){ let seat=room.players.findIndex(p=>p&&p.socketId===sock.id); if(seat<0) seat=room.players.findIndex(p=>!p); if(seat<0) return sock.emit('errorMsg','Soba je puna.'); const old=room.players[seat]; room.players[seat]={name:String(name||`Igrač ${seat+1}`).slice(0,18),socketId:sock.id,connected:true,hand:old?.hand||[]}; sock.data.room=room.code; sock.data.seat=seat; sock.emit('joined',{code:room.code,seat}); if(room.players.every(Boolean)&&room.phase==='lobby') deal(room); emitRoom(room); }
 socket.on('playCard',({id})=>{ const room=rooms.get(socket.data.room), seat=socket.data.seat; if(!room||room.phase!=='playing'||room.turn!==seat) return; const p=room.players[seat], idx=p.hand.findIndex(c=>c.id===id); if(idx<0) return; const [card]=p.hand.splice(idx,1); room.trick.push({seat,card}); if(room.trick.length===4) finishTrick(room); else room.turn=(seat+1)%4; emitRoom(room); });
 socket.on('newDeal',()=>{ const room=rooms.get(socket.data.room); if(!room||room.phase!=='between'||!room.players.every(Boolean)) return; deal(room); emitRoom(room); });
 socket.on('disconnect',()=>{ const room=rooms.get(socket.data.room), seat=socket.data.seat; if(room?.players[seat]?.socketId===socket.id){room.players[seat].connected=false; room.players[seat].socketId=null; room.message=`${room.players[seat].name} je prekinuo vezu.`; emitRoom(room);} });
});
const port=process.env.PORT||3000; server.listen(port,'0.0.0.0',()=>console.log(`Bloody Nine running on ${port}`));
